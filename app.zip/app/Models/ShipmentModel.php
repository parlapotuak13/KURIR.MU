<?php
declare(strict_types=1);

class ShipmentModel
{
    public static function getAll(PDO $pdo): array
    {
        $rows = $pdo->query("SELECT * FROM `shipments` ORDER BY `created_at` DESC")->fetchAll();
        $list = [];
        foreach ($rows as $s) {
            $list[] = [
                'id'                  => (string) $s['id'],
                'createdAt'           => (int) $s['created_at'],
                'sender'              => (string) $s['sender'],
                'city'                => (string) $s['city'],
                'pickupDistrict'      => (string) $s['pickup_district'],
                'pickupAddress'       => (string) $s['pickup_address'],
                'destinationDistrict' => (string) $s['destination_district'],
                'destinationAddress'  => (string) $s['destination_address'],
                'packageType'         => (string) $s['package_type'],
                'quantity'            => (int) $s['quantity'],
                'weightKg'            => (float) $s['weight_kg'],
                'dimL'                => (float) $s['dim_l'],
                'dimW'                => (float) $s['dim_w'],
                'dimH'                => (float) $s['dim_h'],
                'volumeCm3'           => (float) $s['volume_cm3'],
                'volumeLiters'        => (float) $s['volume_liters'],
                'notes'               => (string) $s['notes'],
                'mode'                => (string) $s['mode'],
                'stage'               => (int) $s['stage'],
                'otp'                 => (string) $s['otp'],
            ];
        }
        return $list;
    }

    public static function findById(PDO $pdo, string $id): ?array
    {
        $stmt = $pdo->prepare("SELECT * FROM `shipments` WHERE `id` = ? LIMIT 1");
        $stmt->execute([$id]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public static function create(PDO $pdo, array $data): void
    {
        $stmt = $pdo->prepare("
            INSERT INTO `shipments` (
              `id`, `user_id`, `sender`, `city`, `pickup_district`, `pickup_address`,
              `destination_district`, `destination_address`, `package_type`, `quantity`,
              `weight_kg`, `dim_l`, `dim_w`, `dim_h`, `volume_cm3`, `volume_liters`,
              `notes`, `mode`, `stage`, `otp`, `created_at`
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?, ?)
        ");
        $stmt->execute([
            $data['id'],
            $data['user_id'],
            $data['sender'],
            $data['city'],
            $data['pickup_district'],
            $data['pickup_address'],
            $data['destination_district'],
            $data['destination_address'],
            $data['package_type'],
            $data['quantity'],
            $data['weight_kg'],
            $data['dim_l'],
            $data['dim_w'],
            $data['dim_h'],
            $data['volume_cm3'],
            $data['volume_liters'],
            $data['notes'],
            $data['mode'],
            $data['otp'],
            $data['created_at'],
        ]);
    }

    public static function updateStage(PDO $pdo, string $id, int $stage): void
    {
        $stmt = $pdo->prepare("UPDATE `shipments` SET `stage` = ? WHERE `id` = ?");
        $stmt->execute([$stage, $id]);
    }
}
