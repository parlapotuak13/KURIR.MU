<?php
declare(strict_types=1);

class VendorModel
{
    public static function getHistory(PDO $pdo): array
    {
        $rows = $pdo->query("SELECT `decision`, `decided_at` FROM `vendor_history` ORDER BY `id` ASC LIMIT 20")->fetchAll();
        $list = [];
        foreach ($rows as $h) {
            $list[] = [
                'd'  => (string) $h['decision'],
                'at' => (int) $h['decided_at'],
            ];
        }
        return $list;
    }

    public static function addHistory(PDO $pdo, string $decision, int $decidedAt): void
    {
        $stmt = $pdo->prepare("INSERT INTO `vendor_history` (`decision`, `decided_at`) VALUES (?, ?)");
        $stmt->execute([$decision, $decidedAt]);
    }
}
