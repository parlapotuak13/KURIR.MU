/**
 * 5. Modul Render Antarmuka Pengirim
 */
'use strict';

function renderPengirim(collab, activeShip, cap, obj) {
      const formQty = Number($('p-qty').value) || 2;
      const formWeight = Number($('p-weight').value) || 3.5;
      const formL = Number($('p-dim-l').value) || 30;
      const formW = Number($('p-dim-w').value) || 20;
      const formH = Number($('p-dim-h').value) || 15;
      const volPreview = computeVolumeMetrics(formL, formW, formH, formQty);
      const cmemPreview = computeCmemEmissions(formWeight);

      $('p-calc-vol').textContent = `${volPreview.totalCm3.toLocaleString('id-ID')} cm³ (${fmt(volPreview.totalLiters, 1)} L)`;
      $('p-calc-weight').textContent = `${fmt(formWeight, 1)} kg (Total: ${fmt(cmemPreview.totalLoadKg, 1)} kg)`;
      $('p-calc-cmem').textContent = `${fmt(cmemPreview.co2Shared, 2)} kg CO₂`;

      $('p-alpha').value = state.alpha;
      $('p-beta').value = state.beta;
      $('p-alpha-val').textContent = fmt(obj.alpha, 2);
      $('p-beta-val').textContent = fmt(obj.beta, 2);
      $('p-direct-params').innerHTML = `<span class="math-var">f</span><sub>fuel</sub> = ${fmt(obj.fFuelDirect, 2)} · <span class="math-var">N</span><sub>stop</sub> = ${obj.nStopDirect}`;
      $('p-hub-params').innerHTML = `<span class="math-var">f</span><sub>fuel</sub> = ${fmt(obj.fFuelHub, 2)} · <span class="math-var">N</span><sub>stop</sub> = ${obj.nStopHub}`;
      $('p-direct-score').textContent = `Z = ${fmt(obj.zDirect, 2)}`;
      $('p-hub-score').textContent = `Z = ${fmt(obj.zHub, 2)}`;
      $('p-opt-direct').classList.toggle('winner', obj.zDirect < obj.zHub);
      $('p-opt-hub').classList.toggle('winner', obj.zHub <= obj.zDirect);
      $('p-best-route-text').textContent = Math.abs(obj.zDirect - obj.zHub) < 1e-6
        ? 'Skor kedua rute setara.'
        : obj.hubWins
          ? `Rekomendasi: Rute via Hub (Z = ${fmt(obj.zHub, 2)})`
          : `Rekomendasi: Rute Langsung (Z = ${fmt(obj.zDirect, 2)})`;

      $('p-track-empty').hidden = !!activeShip;
      $('p-track-content').hidden = !activeShip;
      if (activeShip) {
        const isGreen = activeShip.mode === 'hijau';
        $('p-t-id').textContent = activeShip.id;
        $('p-t-mode-badge').textContent = isGreen ? 'Pengiriman Hijau' : 'Rute Langsung';
        $('p-t-mode-badge').className = 'text-xs font-bold px-3 py-1 rounded-full ' + (isGreen ? 'bg-[#e7f1d8] text-[#153d32]' : 'bg-gray-200 text-gray-800');
        $('p-t-status').textContent = STAGES[activeShip.stage];
        $('p-t-route').textContent = `${activeShip.sender} · ${activeShip.pickupDistrict} (${activeShip.pickupAddress}) → ${activeShip.destinationDistrict} (${activeShip.destinationAddress})`;
        $('p-t-specs').innerHTML = `
          <span>📦 ${activeShip.quantity} ${activeShip.packageType}</span>
          <span>⚖️ ${fmt(activeShip.weightKg || 3.5, 1)} kg</span>
          <span>📐 ${activeShip.dimL || 30}×${activeShip.dimW || 20}×${activeShip.dimH || 15} cm (${fmt(activeShip.volumeLiters || 18, 1)} L)</span>
          <span>🌿 ${fmt(cap.cmem.co2Shared, 2)} kg CO₂</span>
        `;

        $('p-steps').innerHTML = STAGES.map((label, i) => `
          <li class="step-item ${i < activeShip.stage ? 'done' : i === activeShip.stage ? 'current' : ''}">
            <span class="font-semibold text-sm">${i < activeShip.stage ? '✓ ' : (i + 1) + '. '}${label}</span>
          </li>
        `).join('');

        $('p-advance-btn').disabled = activeShip.stage >= STAGES.length - 1;

        if (isGreen && collab) {
          $('p-story-text').textContent = `Paket digabungkan di Hub Kel. Merjosari bersama muatan Kilat Raya dan diantar oleh Kurir A (Eco Hemat).`;
          $('p-story-sub').textContent = `Emisi: ${fmt(cap.cmem.co2Shared, 2)} kg CO₂ (Hemat ${fmt(cap.cmem.co2Saved, 2)} kg CO₂).`;
          $('p-svg-title').textContent = 'Rute Kolaborasi via Hub Merjosari';
          $('p-svg-hub-line').style.display = '';
          $('p-svg-hub-node').style.display = '';
          $('p-svg-hub-label').textContent = 'Hub Kel. Merjosari';
        } else {
          $('p-story-text').textContent = `Paket dikirim menggunakan Rute Langsung tanpa transit di Hub Merjosari.`;
          $('p-story-sub').textContent = `Emisi: ${fmt(cap.cmem.co2Separate, 2)} kg CO₂.`;
          $('p-svg-title').textContent = 'Rute Langsung';
          $('p-svg-hub-line').style.display = 'none';
          $('p-svg-hub-node').style.display = 'none';
          $('p-svg-hub-label').textContent = 'Rute Langsung';
        }

        $('p-otp-display').textContent = activeShip.otp;
        const otpPill = $('p-otp-verified-pill');
        otpPill.textContent = state.verified ? 'Terverifikasi' : 'Menunggu Verifikasi';
        otpPill.className = 'text-xs font-bold px-2.5 py-0.5 rounded-full ' + (state.verified ? 'bg-[#e7f1d8] text-[#153d32]' : 'bg-amber-100 text-amber-800');
      }

      $('p-h-empty').hidden = state.shipments.length > 0;
      const hList = $('p-h-list');
      hList.innerHTML = '';
      state.shipments.forEach(s => {
        const card = document.createElement('div');
        card.className = 'surface-card p-4 flex flex-wrap items-center justify-between gap-3 ' + (s.id === state.selectedShipmentId ? 'border-2 border-[#153d32]' : '');
        const info = document.createElement('div');
        info.innerHTML = `
          <div class="flex items-center gap-2">
            <strong class="text-base">${s.id}</strong>
            <span class="text-xs font-bold px-2.5 py-0.5 rounded-full bg-[#e7f1d8] text-[#153d32]">${STAGES[s.stage]}</span>
            <span class="text-xs text-[#5e7268]">${s.mode === 'hijau' ? 'Hijau' : 'Langsung'}</span>
          </div>
          <p class="text-xs text-[#5e7268] mt-1">${s.sender} · ${s.pickupDistrict} → ${s.destinationDistrict} · ${s.quantity} pkt · ${fmt(s.weightKg || 3.5, 1)} kg · ${s.dimL || 30}×${s.dimW || 20}×${s.dimH || 15} cm (${fmt(s.volumeLiters || 18, 1)} L) · OTP: <strong>${s.otp}</strong></p>
        `;
        const btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'btn-secondary text-xs';
        btn.textContent = s.id === state.selectedShipmentId ? 'Aktif' : 'Lacak';
        btn.addEventListener('click', () => {
          state.selectedShipmentId = s.id;
          state.otp = s.otp;
          saveState('select_shipment', { id: s.id });
          switchPengirimTab('track');
        });
        card.append(info, btn);
        hList.appendChild(card);
      });

      const greenList = state.shipments.filter(s => s.mode === 'hijau');
      const totalGreenPkgs = greenList.reduce((acc, s) => acc + s.quantity, 0);
      const totalGreenWeight = greenList.reduce((acc, s) => acc + (Number(s.weightKg) || 3.5), 0);
      const totalGreenVol = greenList.reduce((acc, s) => acc + (Number(s.volumeLiters) || 18.0), 0);
      $('p-i-co2').textContent = `${fmt(cap.cmem.co2Saved, 2)} kg`;
      $('p-i-count').textContent = String(greenList.length);
      $('p-i-pkgs').textContent = `${totalGreenPkgs} paket`;
      $('p-i-weight-vol').textContent = `${fmt(totalGreenWeight, 1)} kg · ${fmt(totalGreenVol, 1)} L`;
    }
