/**
 * 1. Modul State Global & Konstanta Geografis Eco-LogiX
 */
'use strict';

const $ = id => document.getElementById(id);
const DB_KEY = 'ecologix_unified_db_v4';
const STAGES = ['Diterima', 'Pengambilan', 'Transit Hub', 'Serah terima', 'Pengantaran', 'Selesai'];

const COORDS = {
  hub: [-7.9448, 112.6024],
  a: [-7.9521, 112.6160],
  b: [-7.9345, 112.6107]
};

const SHARED_POINTS = [
  COORDS.a,
  [-7.9494, 112.6101],
  COORDS.hub,
  [-7.9416, 112.5984],
  [-7.9370, 112.6050],
  COORDS.b
];

const DIRECT_POINTS_A = [COORDS.a, [-7.9480, 112.6200], [-7.9390, 112.6190], COORDS.b];
const DIRECT_POINTS_B = [COORDS.b, [-7.9309, 112.6040], [-7.9372, 112.5920], [-7.9480, 112.5980], COORDS.a];

const COURIERS = {
  a: { name: 'Kurir A · Eco Hemat', vendor: 'Eco Hemat', point: COORDS.a, baseUsed: 12, max: 30, maxBagasiLiters: 120.0, baseBagasiLiters: 39.0, baseWeightKg: 12.0 },
  b: { name: 'Kurir B · Kilat Raya', vendor: 'Kilat Raya', point: COORDS.b, baseUsed: 12, max: 30, maxBagasiLiters: 120.0, baseBagasiLiters: 39.0, baseWeightKg: 12.0 }
};

const fmt = (n, d = 2) => Number(n).toLocaleString('id-ID', { minimumFractionDigits: d, maximumFractionDigits: d });
const rp = n => 'Rp ' + Math.round(n).toLocaleString('id-ID');
const timeFmt = new Intl.DateTimeFormat('id-ID', { timeZone: 'Asia/Jakarta', hour: '2-digit', minute: '2-digit', hour12: false });
const wib = d => timeFmt.format(d ? new Date(d) : new Date()).replace('.', ':') + ' WIB';

function randomOtp() {
  try {
    const arr = new Uint32Array(1);
    crypto.getRandomValues(arr);
    return String(1000 + (arr[0] % 9000));
  } catch (e) {
    return String(Math.floor(1000 + Math.random() * 9000));
  }
}

function defaultState() {
  const initOtp = randomOtp();
  const now = Date.now();
  return {
    isLoggedIn: false,
    role: 'pengirim',
    currentUser: null,
    accounts: [],
    kTab: 'dashboard',
    pTab: 'create',
    vTab: 'dashboard',
    courier: 'a',
    progress: 0,
    running: false,
    verified: false,
    otp: initOtp,
    alpha: 70,
    beta: 30,
    logs: [],
    vendor: {
      sharing: true,
      threshold: 0.75,
      detour: 2.0,
      area: true,
      volume: true,
      weight: true,
      decision: 'approved',
      decidedAt: now,
      syncAt: now,
      history: [{ d: 'approved', at: now }]
    },
    shipments: [
      {
        id: 'ELX-MLG01',
        createdAt: now - 300000,
        sender: 'UMKM Kopi Malang',
        city: 'Kota Malang',
        pickupDistrict: 'Lowokwaru',
        pickupAddress: 'Jl. MT Haryono No. 45, Dinoyo',
        destinationDistrict: 'Lowokwaru',
        destinationAddress: 'Jl. Gajayana No. 18, Ketawanggede',
        packageType: 'Paket kecil',
        quantity: 2,
        weightKg: 3.5,
        dimL: 30,
        dimW: 20,
        dimH: 15,
        volumeCm3: 18000,
        volumeLiters: 18.0,
        notes: 'Kopi bubuk kemasan rapat',
        mode: 'hijau',
        stage: 0,
        otp: initOtp
      }
    ],
    selectedShipmentId: 'ELX-MLG01'
  };
}

let state = defaultState();
let simTimer = null;
