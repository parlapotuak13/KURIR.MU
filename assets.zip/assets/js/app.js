/**
 * 8. Modul Kontroler Utama Frontend (Navigasi, Event Listeners, & Autentikasi)
 */
'use strict';

function updateAuthScreenVisibility() {
  const loggedIn = !!state.isLoggedIn && !!state.currentUser;
  $('auth-gate-screen').hidden = loggedIn;
  $('app-authenticated-shell').hidden = !loggedIn;
  if (!loggedIn) return;

  const role = state.currentUser.role;
  state.role = role;
  ['pengirim', 'kurir', 'vendor'].forEach(r => {
    $('view-' + r).hidden = r !== role;
    $('nav-' + r).hidden = r !== role;
  });

  $('header-role-pill').textContent = state.currentUser.badge;
  $('active-user-label').textContent = state.currentUser.name;

  renderAll();
  if (role === 'kurir') {
    setTimeout(() => {
      ensureMapsInitialized();
      if (dashMap && state.kTab === 'dashboard') dashMap.invalidateSize();
      if (routeMap && state.kTab === 'route') routeMap.invalidateSize();
    }, 90);
  }
}

function switchKurirTab(tab) {
  state.kTab = tab;
  ['dashboard', 'tasks', 'route', 'hub', 'verify'].forEach(t => {
    $('k-panel-' + t).hidden = t !== tab;
  });
  document.querySelectorAll('[data-k-tab]').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.kTab === tab);
  });
  renderAll();
  setTimeout(() => {
    ensureMapsInitialized();
    if (tab === 'dashboard' && dashMap) dashMap.invalidateSize();
    if (tab === 'route' && routeMap) routeMap.invalidateSize();
  }, 80);
  saveState();
}

function switchPengirimTab(tab) {
  state.pTab = tab;
  ['create', 'track', 'history', 'impact'].forEach(t => {
    $('p-panel-' + t).hidden = t !== tab;
  });
  document.querySelectorAll('[data-p-tab]').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.pTab === tab);
  });
  renderAll();
  saveState();
}

function switchVendorTab(tab) {
  state.vTab = tab;
  ['dashboard', 'fleet', 'collab', 'report'].forEach(t => {
    $('v-panel-' + t).hidden = t !== tab;
  });
  document.querySelectorAll('[data-v-tab]').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.vTab === tab);
  });
  renderAll();
  saveState();
}

function renderAll() {
  const collab = isLoadSharingActive();
  const activeShip = getActiveShipment();
  if (activeShip) {
    state.otp = activeShip.otp;
  }
  const cap = getCapacityMetrics(collab);
  const obj = computeObjectiveScores();

  renderPengirim(collab, activeShip, cap, obj);
  renderKurir(collab, activeShip, cap, obj);
  renderVendor(collab, activeShip, cap);
}

function makeQr() {
  const grid = $('k-qr-art');
  if (!grid) return;
  grid.innerHTML = '';
  for (let y = 0; y < 9; y++) {
    for (let x = 0; x < 9; x++) {
      const cell = document.createElement('span');
      cell.className = 'qr-cell';
      const finder = (ox, oy) => {
        const dx = x - ox, dy = y - oy;
        return dx >= 0 && dx < 3 && dy >= 0 && dy < 3 && (dx === 0 || dy === 0 || dx === 2 || dy === 2 || (dx === 1 && dy === 1));
      };
      if (finder(0, 0) || finder(6, 0) || finder(0, 6) || ((x * 7 + y * 11 + x * y) % 5 < 2)) {
        cell.classList.add('dark');
      }
      grid.appendChild(cell);
    }
  }
}

function stopSim() {
  if (simTimer) clearInterval(simTimer);
  simTimer = null;
  state.running = false;
}

function syncShipmentStageWithProgress() {
  const activeShip = getActiveShipment();
  if (activeShip) {
    activeShip.stage = Math.min(5, Math.floor(state.progress / 20));
  }
}

if (channel) {
  channel.onmessage = ev => {
    if (ev.data) {
      state = {
        ...state,
        ...ev.data,
        isLoggedIn: state.isLoggedIn,
        currentUser: state.currentUser,
        role: state.role,
        running: false
      };
      renderAll();
    }
  };
}

window.addEventListener('storage', e => {
  if (e.key === DB_KEY && e.newValue) {
    try {
      const incoming = JSON.parse(e.newValue);
      state = {
        ...state,
        ...incoming,
        isLoggedIn: state.isLoggedIn,
        currentUser: state.currentUser,
        role: state.role,
        running: false
      };
      renderAll();
    } catch (err) {}
  }
});

// Sinkronisasi berkala dengan MySQL setiap 3 detik
setInterval(async () => {
  if (state.running) return;
  const res = await apiCall('state');
  if (res && res.ok) renderAll();
}, 3000);

// Sub-tab Navigation
document.querySelectorAll('[data-k-tab]').forEach(btn => {
  btn.addEventListener('click', () => switchKurirTab(btn.dataset.kTab));
});
document.querySelectorAll('[data-p-tab]').forEach(btn => {
  btn.addEventListener('click', () => switchPengirimTab(btn.dataset.pTab));
});
document.querySelectorAll('[data-v-tab]').forEach(btn => {
  btn.addEventListener('click', () => switchVendorTab(btn.dataset.vTab));
});

// Kurir controls
$('k-courier-a').addEventListener('click', () => {
  state.courier = 'a';
  renderAll();
  saveState('update_courier', { courier: 'a', progress: state.progress });
});
$('k-courier-b').addEventListener('click', () => {
  state.courier = 'b';
  renderAll();
  saveState('update_courier', { courier: 'b', progress: state.progress });
});
$('k-hub-to-verify').addEventListener('click', () => switchKurirTab('verify'));

$('k-toggle-separate').addEventListener('change', e => {
  if (!dashMap || !separateLayers) return;
  if (e.target.checked) separateLayers.addTo(dashMap);
  else dashMap.removeLayer(separateLayers);
});
$('k-toggle-shared').addEventListener('change', e => {
  if (!dashMap || !sharedLayer) return;
  if (e.target.checked) sharedLayer.addTo(dashMap);
  else dashMap.removeLayer(sharedLayer);
});

$('k-sim-btn').addEventListener('click', () => {
  if (state.running) {
    stopSim();
    renderAll();
    saveState('update_courier', { courier: state.courier, progress: state.progress });
    return;
  }
  if (state.progress >= 100) state.progress = 0;
  state.running = true;
  renderAll();
  simTimer = setInterval(() => {
    state.progress = Math.min(100, state.progress + 2);
    syncShipmentStageWithProgress();
    if (state.progress >= 100) {
      stopSim();
      saveState('update_courier', { courier: state.courier, progress: state.progress });
      showToast('Perjalanan selesai.');
    }
    renderAll();
  }, 150);
});

$('k-sim-step-btn').addEventListener('click', () => {
  stopSim();
  state.progress = state.progress >= 100 ? 0 : Math.min(100, (Math.floor(state.progress / 20) + 1) * 20);
  syncShipmentStageWithProgress();
  renderAll();
  saveState('update_courier', { courier: state.courier, progress: state.progress });
});

$('k-fill-otp-btn').addEventListener('click', () => {
  $('k-otp-input').value = state.otp;
});

$('k-otp-form').addEventListener('submit', e => {
  e.preventDefault();
  if (state.verified) return;
  const val = $('k-otp-input').value.trim();
  const msgEl = $('k-otp-msg');
  if (val !== state.otp) {
    msgEl.textContent = 'Kode OTP tidak sesuai.';
    msgEl.style.color = '#b91c1c';
    return;
  }
  state.verified = true;
  if (state.progress < 60) {
    state.progress = 60;
    syncShipmentStageWithProgress();
  }
  const logEntry = `${wib(Date.now())} — 12 paket kolaborasi & resi ${state.selectedShipmentId} terverifikasi (OTP ${state.otp})`;
  state.logs.push(logEntry);
  msgEl.textContent = 'Serah terima berhasil diverifikasi.';
  msgEl.style.color = '#287044';
  showToast('OTP terverifikasi.');
  renderAll();
  saveState('verify_otp', { otp: val, logText: logEntry });
});

// Pengirim live inputs
['p-qty', 'p-weight', 'p-dim-l', 'p-dim-w', 'p-dim-h'].forEach(id => {
  $(id).addEventListener('input', () => renderAll());
});

['p-alpha', 'p-beta'].forEach(id => {
  $(id).addEventListener('input', () => {
    state.alpha = Number($('p-alpha').value);
    state.beta = Number($('p-beta').value);
    renderAll();
    saveState('update_weights', { alpha: state.alpha, beta: state.beta });
  });
});

$('p-form').addEventListener('submit', e => {
  e.preventDefault();
  const qty = Number($('p-qty').value);
  const weightKg = Number($('p-weight').value);
  const dimL = Number($('p-dim-l').value);
  const dimW = Number($('p-dim-w').value);
  const dimH = Number($('p-dim-h').value);
  const errEl = $('p-form-err');

  if (!Number.isInteger(qty) || qty < 1 || qty > 18) {
    errEl.textContent = 'Jumlah paket harus antara 1 hingga 18 paket.';
    errEl.hidden = false;
    return;
  }
  if (!Number.isFinite(weightKg) || weightKg <= 0 || weightKg > 60) {
    errEl.textContent = 'Berat total paket harus antara 0,1 kg hingga 60 kg.';
    errEl.hidden = false;
    return;
  }
  const vol = computeVolumeMetrics(dimL, dimW, dimH, qty);
  if (vol.totalLiters > 80) {
    errEl.textContent = `Volume total (${fmt(vol.totalLiters, 1)} L) melebihi batas bagasi (80 L).`;
    errEl.hidden = false;
    return;
  }
  errEl.hidden = true;

  const newOtp = randomOtp();
  const newShip = {
    id: 'ELX-' + Date.now().toString(36).toUpperCase().slice(-4) + Math.random().toString(36).toUpperCase().slice(2, 4),
    createdAt: Date.now(),
    sender: $('p-sender').value.trim() || 'Pengirim',
    city: $('p-city').value.trim() || 'Kota Malang',
    pickupDistrict: $('p-pd').value,
    pickupAddress: $('p-pa').value.trim(),
    destinationDistrict: $('p-dd').value,
    destinationAddress: $('p-da').value.trim(),
    packageType: $('p-pt').value,
    quantity: qty,
    weightKg: weightKg,
    dimL: vol.l,
    dimW: vol.w,
    dimH: vol.h,
    volumeCm3: vol.totalCm3,
    volumeLiters: vol.totalLiters,
    notes: $('p-notes').value.trim(),
    mode: document.querySelector('input[name="p-mode"]:checked').value,
    stage: 0,
    otp: newOtp
  };
  state.shipments.unshift(newShip);
  state.selectedShipmentId = newShip.id;
  state.otp = newOtp;
  state.progress = 0;
  state.verified = false;
  saveState('create_shipment', newShip);
  showToast(`Pengiriman ${newShip.id} berhasil dibuat.`);
  switchPengirimTab('track');
});

$('p-advance-btn').addEventListener('click', () => {
  const s = getActiveShipment();
  if (!s || s.stage >= STAGES.length - 1) return;
  s.stage++;
  state.progress = s.stage * 20;
  const logText = `${wib(Date.now())} — Resi ${s.id} terverifikasi`;
  if (s.stage >= 4 && !state.verified) {
    state.verified = true;
    state.logs.push(logText);
  }
  renderAll();
  saveState('advance_shipment', { id: s.id, logText });
});

// Vendor 3PL controls
['v-sharing', 'v-area', 'v-volume', 'v-weight'].forEach(id => {
  $(id).addEventListener('change', e => {
    const key = id.replace('v-', '');
    state.vendor[key] = e.target.checked;
    renderAll();
    saveState('update_vendor', { vendor: state.vendor, recordHistory: false });
  });
});

$('v-threshold').addEventListener('input', e => {
  state.vendor.threshold = Number(e.target.value);
  renderAll();
});
$('v-threshold').addEventListener('change', () => saveState('update_vendor', { vendor: state.vendor, recordHistory: false }));

$('v-detour').addEventListener('change', e => {
  state.vendor.detour = Math.max(0, Math.min(20, Number(e.target.value) || 0));
  renderAll();
  saveState('update_vendor', { vendor: state.vendor, recordHistory: false });
});

$('v-ok-btn').addEventListener('click', () => {
  if (getVendorBlocker()) return renderAll();
  state.vendor.decision = 'approved';
  state.vendor.decidedAt = Date.now();
  state.vendor.history = state.vendor.history.concat({ d: 'approved', at: Date.now() }).slice(-10);
  showToast('Kolaborasi disetujui.');
  renderAll();
  saveState('update_vendor', { vendor: state.vendor, recordHistory: true });
});

$('v-no-btn').addEventListener('click', () => {
  state.vendor.decision = 'rejected';
  state.vendor.decidedAt = null;
  state.vendor.history = state.vendor.history.concat({ d: 'rejected', at: Date.now() }).slice(-10);
  showToast('Kolaborasi ditolak.');
  renderAll();
  saveState('update_vendor', { vendor: state.vendor, recordHistory: true });
});

// Reset Modal
$('btn-global-reset').addEventListener('click', () => {
  $('app-modal').hidden = false;
});
$('modal-close').addEventListener('click', () => {
  $('app-modal').hidden = true;
});
$('confirm-cancel-btn').addEventListener('click', () => {
  $('app-modal').hidden = true;
});
$('confirm-ok-btn').addEventListener('click', () => {
  stopSim();
  const curUser = state.currentUser;
  const savedAccs = state.accounts || [];
  state = defaultState();
  state.accounts = savedAccs;
  state.isLoggedIn = !!curUser;
  state.currentUser = curUser;
  if (curUser) state.role = curUser.role;
  saveState('reset_data', {});
  updateAuthScreenVisibility();
  $('app-modal').hidden = true;
  showToast('Data berhasil direset.');
});

// Login & Sign Up Logic
let authMode = 'login';
function setAuthTab(mode) {
  authMode = mode;
  $('auth-tab-login').className = 'py-2.5 px-3 rounded-lg font-bold text-xs sm:text-sm transition cursor-pointer ' +
    (mode === 'login' ? 'bg-[#153d32] text-white' : 'text-[#5e7268]');
  $('auth-tab-register').className = 'py-2.5 px-3 rounded-lg font-bold text-xs sm:text-sm transition cursor-pointer ' +
    (mode === 'register' ? 'bg-[#153d32] text-white' : 'text-[#5e7268]');
  $('auth-register-fields').hidden = mode !== 'register';
  $('auth-submit-btn').textContent = mode === 'login' ? 'Masuk' : 'Daftar & Masuk';
  $('auth-msg').textContent = '';
}

$('auth-tab-login').addEventListener('click', () => setAuthTab('login'));
$('auth-tab-register').addEventListener('click', () => setAuthTab('register'));

$('auth-form').addEventListener('submit', async e => {
  e.preventDefault();
  const email = $('auth-email').value.trim().toLowerCase();
  const pass = $('auth-pass').value;
  const roleChoice = $('auth-role-select').value;
  const name = $('auth-name').value.trim();
  const msgEl = $('auth-msg');
  msgEl.textContent = '';

  const res = await apiCall(authMode === 'register' ? 'register' : 'login', {
    email,
    pass,
    roleChoice,
    name
  });

  if (res && res.ok && res.state) {
    stopSim();
    if (state.currentUser && state.currentUser.role === 'pengirim' && state.currentUser.name) {
      $('p-sender').value = state.currentUser.name;
    }
    updateAuthScreenVisibility();
    return;
  }

  if (res && res.error && res.error.includes('Kata sandi salah')) {
    msgEl.textContent = res.error;
    msgEl.style.color = '#b91c1c';
    return;
  }

  const roleMap = {
    pengirim: { role: 'pengirim', courierCode: null, badge: 'Pengirim' },
    kurir_a: { role: 'kurir', courierCode: 'a', badge: 'Kurir · Eco Hemat' },
    kurir_b: { role: 'kurir', courierCode: 'b', badge: 'Kurir · Kilat Raya' },
    vendor: { role: 'vendor', courierCode: null, badge: 'Vendor 3PL' }
  };
  const rm = roleMap[roleChoice] || roleMap.pengirim;
  const displayName = name || email.split('@')[0];
  const userAccount = { id: Date.now(), email, name: displayName, role: rm.role, courierCode: rm.courierCode, badge: rm.badge };
  stopSim();
  state.currentUser = userAccount;
  state.isLoggedIn = true;
  state.role = userAccount.role;
  if (userAccount.courierCode) state.courier = userAccount.courierCode;
  if (userAccount.role === 'pengirim' && userAccount.name) $('p-sender').value = userAccount.name;
  saveState();
  updateAuthScreenVisibility();
});

$('btn-logout').addEventListener('click', async () => {
  stopSim();
  state.isLoggedIn = false;
  state.currentUser = null;
  await apiCall('logout', {});
  saveState();
  updateAuthScreenVisibility();
});

makeQr();
updateAuthScreenVisibility();
renderAll();
