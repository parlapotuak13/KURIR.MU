/**
 * 2. Modul Mesin Matematika: Haversine, Indeks Kemiripan δ, Emisi CMEM,
 *    Kapasitas Volumetrik Bagasi (P×L×T), & Kalkulator Fungsi Objektif Z
 */
'use strict';

function haversine(p, q) {
  const r = Math.PI / 180;
  const dLat = (q[0] - p[0]) * r;
  const dLon = (q[1] - p[1]) * r;
  const h = Math.sin(dLat / 2) ** 2 + Math.cos(p[0] * r) * Math.cos(q[0] * r) * Math.sin(dLon / 2) ** 2;
  return 6371 * 2 * Math.atan2(Math.sqrt(h), Math.sqrt(1 - h));
}

function computeDelta(from, to) {
  const direct = haversine(from, to);
  const via = haversine(from, COORDS.hub) + haversine(COORDS.hub, to);
  return Math.max(0, Math.min(1, 1 - 0.5 * ((via - direct) / via)));
}

function computeCmemEmissions(senderWeightKg) {
  const w = Math.max(0.1, Number(senderWeightKg) || 3.5);
  const totalLoadKg = 24.0 + w;
  const factorPerKm = 0.0645 + 0.0002 * totalLoadKg;
  const co2Separate = +(36 * factorPerKm).toFixed(2);
  const co2Shared = +(26 * factorPerKm).toFixed(2);
  const co2Saved = +(co2Separate - co2Shared).toFixed(2);
  return { totalLoadKg, co2Separate, co2Shared, co2Saved };
}

function computeVolumeMetrics(dimL, dimW, dimH, qty) {
  const l = Math.max(1, Number(dimL) || 30);
  const w = Math.max(1, Number(dimW) || 20);
  const h = Math.max(1, Number(dimH) || 15);
  const q = Math.max(1, Number(qty) || 1);
  const unitCm3 = l * w * h;
  const totalCm3 = unitCm3 * q;
  const totalLiters = +(totalCm3 / 1000).toFixed(2);
  return { l, w, h, q, unitCm3, totalCm3, totalLiters };
}

function getActiveShipment() {
  return state.shipments.find(s => s.id === state.selectedShipmentId) || state.shipments[0] || null;
}

function getCapacityMetrics(collabActive) {
  const activeShip = getActiveShipment();
  const senderVolLiters = activeShip ? (Number(activeShip.volumeLiters) || 18.0) : 18.0;
  const senderWeightKg = activeShip ? (Number(activeShip.weightKg) || 3.5) : 3.5;

  const maxPackages = COURIERS.a.max; // 30
  const basePackages = COURIERS.a.baseUsed; // 12
  const collabPackages = collabActive ? 12 : 0;
  const usedPackages = basePackages + collabPackages; // 24 saat kolaborasi aktif
  const remPackages = Math.max(0, maxPackages - usedPackages); // 30 - 24 = 6 paket

  const maxBagasiLiters = COURIERS.a.maxBagasiLiters; // 120.0 L
  const usedBagasiLiters = +(COURIERS.a.baseBagasiLiters + (collabActive ? (39.0 + senderVolLiters) : senderVolLiters)).toFixed(1);
  const remBagasiLiters = +Math.max(0, maxBagasiLiters - usedBagasiLiters).toFixed(1);

  const cmem = computeCmemEmissions(senderWeightKg);

  return {
    maxPackages,
    basePackages,
    usedPackages,
    remPackages,
    maxBagasiLiters,
    usedBagasiLiters,
    remBagasiLiters,
    senderVolLiters,
    senderWeightKg,
    cmem
  };
}

function getVendorBlocker() {
  const v = state.vendor;
  const delta = computeDelta(COORDS.a, COORDS.b);
  const detourKm = 2.0;
  const activeShip = getActiveShipment();
  const senderVolLiters = activeShip ? (Number(activeShip.volumeLiters) || 18.0) : 18.0;
  if (!v.sharing) return 'Fitur Load-Sharing dinonaktifkan.';
  if (delta < v.threshold) return `Indeks kemiripan rute (δ = ${fmt(delta, 2)}) di bawah ambang minimum (δ = ${fmt(v.threshold, 2)}).`;
  if (detourKm > v.detour) return `Jarak memutar (2,0 km) melebihi batas maksimum (${fmt(v.detour, 1)} km).`;
  if (COURIERS.a.baseUsed + 12 > COURIERS.a.max) return 'Kapasitas paket Kurir A tidak mencukupi.';
  if (COURIERS.a.baseBagasiLiters + 39.0 + senderVolLiters > COURIERS.a.maxBagasiLiters) {
    return 'Volume paket melebihi kapasitas bagasi Kurir A (120,0 L).';
  }
  return '';
}

function isLoadSharingActive() {
  if (getVendorBlocker()) return false;
  return state.vendor.decision === 'approved';
}

function computeObjectiveScores() {
  const activeShip = getActiveShipment();
  const w = activeShip ? (Number(activeShip.weightKg) || 3.5) : 3.5;
  const weightAdjustment = +((w - 3.5) * 0.08).toFixed(2);
  const fFuelDirect = +(8.0 + weightAdjustment).toFixed(2);
  const fFuelHub = +(5.0 + weightAdjustment * 0.7).toFixed(2);
  const nStopDirect = 3;
  const nStopHub = 5;

  const alpha = state.alpha / 100;
  const beta = state.beta / 100;
  const zDirect = alpha * fFuelDirect + beta * nStopDirect;
  const zHub = alpha * fFuelHub + beta * nStopHub;
  return { alpha, beta, fFuelDirect, fFuelHub, nStopDirect, nStopHub, zDirect, zHub, hubWins: zHub <= zDirect };
}
