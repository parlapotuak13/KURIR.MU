/**
 * 7. Modul Render Antarmuka Vendor 3PL
 */
'use strict';

function renderVendor(collab, activeShip, cap) {
      const v = state.vendor;
      const blocker = getVendorBlocker();
      const used = cap.usedPackages;
      const rem = cap.remPackages;
      const load = Math.round((used / cap.maxPackages) * 100);
      const load0 = Math.round((cap.basePackages / cap.maxPackages) * 100);
      const load1 = Math.round(((cap.basePackages + 12) / cap.maxPackages) * 100);
      const co0 = cap.cmem.co2Separate;
      const co1 = cap.cmem.co2Shared;
      const c0 = 45000 / 12, c1 = 68600 / 24;

      const statusText = collab
        ? 'Kolaborasi Aktif'
        : v.decision === 'rejected'
          ? 'Rute Langsung'
          : 'Menunggu Syarat';

      $('v-st-badge').textContent = statusText;
      $('v-st-badge').className = 'text-xs sm:text-sm font-bold px-3.5 py-1 rounded-full ' + (collab ? 'bg-[#153d32] text-white' : 'bg-amber-200 text-amber-900');
      $('v-rq-val').textContent = statusText;

      $('v-m-load').textContent = `${load0}% → ${load1}%`;
      $('v-m-load2').textContent = `${load}% (${used}/${cap.maxPackages} paket · Sisa ${rem} paket)`;
      $('v-m-vmt').textContent = '36 → 26 km';
      $('v-m-vmt2').textContent = collab ? '26 km gabungan (Kurir A 20 km + Kurir B 6 km)' : '36 km terpisah (18 km + 18 km)';
      $('v-m-co2').textContent = `${fmt(co0, 2)} → ${fmt(co1, 2)} kg`;
      $('v-m-co22').textContent = `${fmt(collab ? co1 : co0, 2)} kg CO₂ (Muatan ${fmt(cap.cmem.totalLoadKg, 1)} kg)`;
      $('v-m-cost').textContent = `${rp(c0)} → ${rp(c1)}`;
      $('v-m-cost2').textContent = `${rp(collab ? c1 : c0)} per paket`;

      $('v-a-d').textContent = `${used} dari ${cap.maxPackages} paket · ${load}% (Sisa ${rem} paket)`;
      $('v-a-f').style.width = `${load}%`;
      $('v-a-pb').setAttribute('aria-valuenow', String(load));
      $('v-a-r').textContent = `V_rem = V_max − V_isi = ${cap.maxPackages} − ${used} = ${rem} paket`;
      $('v-a-bagasi').textContent = `Bagasi: ${fmt(cap.usedBagasiLiters, 1)} / ${fmt(cap.maxBagasiLiters, 1)} L (Sisa ${fmt(cap.remBagasiLiters, 1)} L) · Berat muatan: ${fmt(cap.cmem.totalLoadKg, 1)} kg`;

      $('v-sharing').checked = v.sharing;
      $('v-area').checked = v.area;
      $('v-volume').checked = v.volume;
      $('v-weight').checked = v.weight;
      if (document.activeElement !== $('v-threshold')) $('v-threshold').value = v.threshold;
      if (document.activeElement !== $('v-detour')) $('v-detour').value = v.detour;
      $('v-th-o').textContent = `δ = ${fmt(v.threshold, 2)}`;
      $('v-req-co2-save').textContent = fmt(cap.cmem.co2Saved, 2);

      $('v-ok-btn').disabled = !!blocker;
      $('v-why').hidden = !blocker;
      $('v-why').textContent = blocker;

      $('v-tb').innerHTML = `
        <tr><th class="py-2 px-2">Jarak Gabungan (VMT)</th><td class="py-2 px-2">36 km</td><td class="py-2 px-2 font-bold text-[#287044]">26 km</td></tr>
        <tr><th class="py-2 px-2">Kapasitas Paket (V_rem)</th><td class="py-2 px-2">12 / 30 (Sisa 18)</td><td class="py-2 px-2 font-bold text-[#287044]">24 / 30 (Sisa 6)</td></tr>
        <tr><th class="py-2 px-2">Volume Bagasi</th><td class="py-2 px-2">39,0 / 120,0 L</td><td class="py-2 px-2 font-bold text-[#287044]">${fmt(cap.usedBagasiLiters, 1)} / 120,0 L (Sisa ${fmt(cap.remBagasiLiters, 1)} L)</td></tr>
        <tr><th class="py-2 px-2">Emisi CO₂ (${fmt(cap.cmem.totalLoadKg, 1)} kg)</th><td class="py-2 px-2">${fmt(co0, 2)} kg</td><td class="py-2 px-2 font-bold text-[#287044]">${fmt(co1, 2)} kg</td></tr>
        <tr><th class="py-2 px-2">Biaya per Paket</th><td class="py-2 px-2">${rp(c0)}</td><td class="py-2 px-2 font-bold text-[#287044]">${rp(c1)}</td></tr>
      `;

      const tStr = collab && v.decidedAt ? wib(v.decidedAt) : '-';
      $('v-h1').textContent = `Kilat Raya → Hub Merjosari: ${collab ? 'Disetujui (' + tStr + ')' : 'Menunggu'}`;
      $('v-h2').textContent = `Hub Merjosari → Eco Hemat: ${state.verified ? 'Terverifikasi OTP' : collab ? 'Menunggu OTP' : 'Nonaktif'}`;
      $('v-h-otp').textContent = state.logs.length ? state.logs[state.logs.length - 1] : `OTP Aktif: ${state.otp}`;

      $('v-hist').innerHTML = v.history.length
        ? v.history.slice().reverse().map(h => `<li>${wib(h.at)} · <strong>${h.d === 'approved' ? 'Disetujui' : 'Ditolak'}</strong></li>`).join('')
        : '<li>Belum ada keputusan.</li>';
    }
