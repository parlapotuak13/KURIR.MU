/**
 * 6. Modul Render Antarmuka Kurir
 */
'use strict';

function renderKurir(collab, activeShip, cap, obj) {
      const loadPct = Math.round((cap.usedPackages / cap.maxPackages) * 100);

      $('k-map-badge').textContent = collab ? 'Via Hub Merjosari' : 'Rute Langsung';
      $('k-vmt-value').textContent = collab ? '36 → 26 km' : '36 km';
      $('k-vmt-sub').textContent = collab ? 'Hemat 10 km' : 'Rute terpisah';
      $('k-carbon-value').textContent = collab ? `${fmt(cap.cmem.co2Saved, 2)} kg` : '0,00 kg';
      $('k-carbon-sub').textContent = collab
        ? `${fmt(cap.cmem.co2Separate, 2)} → ${fmt(cap.cmem.co2Shared, 2)} kg`
        : `${fmt(cap.cmem.co2Separate, 2)} kg CO₂`;
      $('k-fill-tag').textContent = `${cap.usedPackages} / ${cap.maxPackages} paket (Sisa ${cap.remPackages} paket)`;
      $('k-fill-value').textContent = collab ? `40% → ${loadPct}%` : '40%';
      $('k-fill-bar').style.width = loadPct + '%';
      $('k-bagasi-sub').textContent = `Bagasi: ${fmt(cap.usedBagasiLiters, 1)} / ${fmt(cap.maxBagasiLiters, 1)} L (Sisa ${fmt(cap.remBagasiLiters, 1)} L) · Berat muatan: ${fmt(cap.cmem.totalLoadKg, 1)} kg`;

      $('k-tbl-co2-before').textContent = `${fmt(cap.cmem.co2Separate, 2)} kg CO₂`;
      $('k-tbl-co2').textContent = `${fmt(cap.cmem.co2Shared, 2)} kg CO₂`;
      $('k-tbl-cap').textContent = `${cap.usedPackages} / ${cap.maxPackages} paket (Sisa ${cap.remPackages})`;

      const c = COURIERS[state.courier];
      const other = COURIERS[state.courier === 'a' ? 'b' : 'a'];
      $('k-courier-a').classList.toggle('active', state.courier === 'a');
      $('k-courier-b').classList.toggle('active', state.courier === 'b');
      $('k-courier-name').textContent = c.name;

      $('k-courier-pkg-badge').textContent = state.courier === 'a'
        ? `${cap.usedPackages} / ${c.max} paket`
        : (collab ? '12 paket → Hub' : '12 / 30 paket');

      $('k-courier-detail').textContent = state.courier === 'a'
        ? `Mengangkut 12 paket Eco Hemat + ${collab ? '12 paket Kilat Raya dari Hub Kel. Merjosari (Total 24 dari 30 paket, sisa kapasitas 6 paket).' : '0 paket tambahan (Sisa kapasitas 18 paket).'}`
        : `Mengantar 12 paket Kilat Raya menuju Hub Kel. Merjosari untuk diserahterimakan ke Kurir A.`;

      const distToHub = haversine(c.point, COORDS.hub);
      const delta = computeDelta(c.point, other.point);

      $('k-match-distance').textContent = `${fmt(distToHub, 2)} km`;
      $('k-match-delta').textContent = fmt(delta, 2);
      $('k-match-threshold').textContent = fmt(state.vendor.threshold, 2);
      $('k-match-capacity').textContent = `${cap.remPackages} paket`;
      $('k-match-cap-sub').textContent = `${cap.maxPackages} − ${cap.usedPackages} = ${cap.remPackages} paket`;
      $('k-match-bagasi').textContent = `${fmt(cap.remBagasiLiters, 1)} L`;
      $('k-match-bagasi-sub').textContent = `${fmt(cap.maxBagasiLiters, 0)} − ${fmt(cap.usedBagasiLiters, 1)} = ${fmt(cap.remBagasiLiters, 1)} L`;

      $('k-formula-vrem').textContent = `${cap.maxPackages} − ${cap.usedPackages} = ${cap.remPackages} paket`;
      $('k-formula-bagasi').textContent = `${fmt(cap.maxBagasiLiters, 1)} − ${fmt(cap.usedBagasiLiters, 1)} = ${fmt(cap.remBagasiLiters, 1)} L`;
      $('k-cmem-supply-tag').textContent = `Berat Muatan: ${fmt(cap.cmem.totalLoadKg, 1)} kg`;

      const blocker = getVendorBlocker();
      const pill = $('k-vendor-policy-pill');
      if (collab) {
        pill.textContent = 'Disetujui';
        pill.className = 'text-xs font-bold px-3 py-1 rounded-full bg-[#e7f1d8] text-[#153d32]';
        $('k-match-decision').textContent = 'Load-Sharing via Hub Merjosari';
        $('k-match-decision').style.color = '#287044';
      } else {
        pill.textContent = 'Rute Langsung';
        pill.className = 'text-xs font-bold px-3 py-1 rounded-full bg-amber-100 text-amber-900';
        $('k-match-decision').textContent = 'Rute Langsung (' + (blocker || 'Ditolak Vendor') + ')';
        $('k-match-decision').style.color = '#92400e';
      }

      const pts = getActiveRoutePoints();
      const useHubRoute = collab && obj.hubWins;
      $('k-sim-route-label').textContent = useHubRoute
        ? `Rute Kolaborasi via Hub Merjosari (${COURIERS[state.courier].vendor})`
        : `Rute Langsung (${COURIERS[state.courier].vendor})`;
      $('k-sim-pct').textContent = `${Math.round(state.progress)}%`;

      if (simPolyline && routeMap) {
        simPolyline.setLatLngs(pts);
        simPolyline.setStyle({ color: useHubRoute ? '#247c48' : '#64748b' });
      }
      if (simMarker && pts.length > 1) {
        const seg = (pts.length - 1) * (state.progress / 100);
        const idx = Math.min(pts.length - 2, Math.floor(seg));
        const t = Math.min(1, seg - idx);
        simMarker.setLatLng([
          pts[idx][0] + (pts[idx + 1][0] - pts[idx][0]) * t,
          pts[idx][1] + (pts[idx + 1][1] - pts[idx][1]) * t
        ]);
      }

      const step = Math.min(5, Math.floor(state.progress / 20));
      document.querySelectorAll('#k-step-list .step-item').forEach((el, i) => {
        el.classList.toggle('done', i < step);
        el.classList.toggle('current', i === step);
      });

      const totalCo2 = useHubRoute ? cap.cmem.co2Shared : cap.cmem.co2Separate;
      $('k-running-carbon').textContent = `${fmt((totalCo2 * state.progress) / 100, 2)} kg CO₂`;
      $('k-sim-btn').textContent = state.progress >= 100
        ? '↺ Ulangi'
        : state.running
          ? '⏸ Jeda'
          : state.progress > 0
            ? '▶ Lanjutkan'
            : '▶ Mulai';

      const atHubCount = state.progress >= 40 && state.progress < 80 ? 12 : 0;
      $('k-hub-count').textContent = `${atHubCount} / 12 paket`;
      const greenShips = state.shipments.filter(s => s.mode === 'hijau');
      $('k-hub-user-ships').textContent = `${greenShips.length} resi (${greenShips.reduce((a, b) => a + b.quantity, 0)} pkt)`;
      $('k-hub-verify-status').textContent = state.verified ? 'Terverifikasi' : 'Menunggu OTP';
      $('k-hub-verify-status').className = 'brand text-xl font-bold mt-1 block ' + (state.verified ? 'text-[#287044]' : 'text-[#92400e]');

      const pkgList = $('k-package-list');
      pkgList.innerHTML = '';
      state.shipments.forEach(s => {
        const row = document.createElement('div');
        row.className = 'flex justify-between items-center gap-3 py-2.5 text-xs sm:text-sm bg-[#f5faed] px-3 rounded-lg my-1';
        const left = document.createElement('div');
        left.innerHTML = `<strong class="text-[#153d32]">${s.id} · ${s.sender}</strong> <span class="text-xs text-[#5e7268]">(${s.quantity} ${s.packageType} · ${fmt(s.weightKg || 3.5, 1)} kg · ${s.dimL || 30}×${s.dimW || 20}×${s.dimH || 15} cm = ${fmt(s.volumeLiters || 18, 1)} L)</span>`;
        const right = document.createElement('span');
        right.className = 'font-bold text-[#287044]';
        right.textContent = STAGES[s.stage];
        row.append(left, right);
        pkgList.appendChild(row);
      });

      for (let n = 1; n <= 12; n++) {
        const row = document.createElement('div');
        row.className = 'flex justify-between items-center gap-3 py-2.5 text-xs sm:text-sm px-2';
        const name = document.createElement('strong');
        name.textContent = `Paket ECO-${String(n).padStart(3, '0')} (Kilat Raya → Eco Hemat)`;
        const status = document.createElement('span');
        status.className = 'font-semibold text-[#3b7654]';
        status.textContent = state.progress >= 100
          ? 'Selesai'
          : state.verified
            ? 'Terverifikasi'
            : state.progress >= 80
              ? 'Pengantaran'
              : state.progress >= 60
                ? 'Serah Terima'
                : state.progress >= 40
                  ? 'Di Hub'
                  : state.progress >= 20
                    ? 'Pengambilan'
                    : 'Diterima';
        row.append(name, status);
        pkgList.appendChild(row);
      }

      $('k-demo-otp').textContent = state.otp;
      $('k-verified-count').textContent = `${state.verified ? 12 : 0} / 12 paket`;
      $('k-verify-btn').disabled = state.verified;
      $('k-verify-btn').textContent = state.verified ? 'Sudah Terverifikasi' : 'Verifikasi';
      $('k-log-list').innerHTML = state.logs.length
        ? state.logs.map(l => `<div class="py-1 border-b border-[#edf2e8]">✓ ${l}</div>`).join('')
        : '<p class="text-[#5e7268]">Belum ada riwayat verifikasi.</p>';
    }
