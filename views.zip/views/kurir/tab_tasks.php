<section id="k-panel-tasks" class="k-panel" hidden>
          <div class="mb-4">
            <p class="eyebrow">KOORDINASI MUATAN</p>
            <h2 class="brand text-2xl font-bold mt-0.5">Pencocokan Rute &amp; Kapasitas</h2>
          </div>

          <div class="flex flex-wrap gap-2 mb-4" role="group" aria-label="Pilih kurir">
            <button type="button" id="k-courier-a" class="pill-btn active">Kurir A · Eco Hemat</button>
            <button type="button" id="k-courier-b" class="pill-btn">Kurir B · Kilat Raya</button>
          </div>

          <div class="surface-card p-5 mb-4">
            <div class="flex flex-wrap justify-between items-start gap-3">
              <div>
                <p class="eyebrow">ARMADA AKTIF</p>
                <h3 id="k-courier-name" class="brand text-2xl font-bold mt-1">Kurir A · Eco Hemat</h3>
              </div>
              <span id="k-courier-pkg-badge" class="bg-[#e7f1d8] text-[#153d32] rounded-full px-3.5 py-1 text-sm font-bold">24 / 30 paket</span>
            </div>
            <p id="k-courier-detail" class="text-sm text-[#5e7268] mt-3"></p>
          </div>

          <div class="surface-card p-5">
            <div class="flex flex-wrap items-center justify-between gap-2">
              <h3 class="font-bold text-base">Mesin Pencocokan Rute</h3>
              <span id="k-vendor-policy-pill" class="text-xs font-bold px-3 py-1 rounded-full bg-[#e7f1d8] text-[#153d32]">Disetujui</span>
            </div>

            <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3 mt-4 text-center">
              <div class="bg-[#f3f6ec] rounded-xl p-3">
                <div class="text-xs text-[#5e7268]">Jarak ke Hub</div>
                <strong id="k-match-distance" class="block mt-1 text-lg font-bold text-[#153d32]">1,71 km</strong>
              </div>
              <div class="bg-[#f3f6ec] rounded-xl p-3">
                <div class="text-xs text-[#5e7268]">Indeks Kemiripan (<span class="math-var">δ</span>)</div>
                <strong id="k-match-delta" class="block mt-1 text-lg font-bold text-[#153d32]">0,82</strong>
              </div>
              <div class="bg-[#f3f6ec] rounded-xl p-3">
                <div class="text-xs text-[#5e7268]">Ambang (<span class="math-var">δ</span><sub>min</sub>)</div>
                <strong id="k-match-threshold" class="block mt-1 text-lg font-bold text-[#153d32]">0,75</strong>
              </div>
              <div class="bg-[#f3f6ec] rounded-xl p-3 border border-[#b8e071]">
                <div class="text-xs text-[#153d32] font-semibold">Sisa Kapasitas (<span class="math-var">V</span><sub>rem</sub>)</div>
                <strong id="k-match-capacity" class="block mt-1 text-lg font-bold text-[#153d32]">6 paket</strong>
                <span id="k-match-cap-sub" class="block text-[10px] text-[#5e7268]">30 − 24 = 6 paket</span>
              </div>
              <div class="bg-[#f3f6ec] rounded-xl p-3 border border-[#b8e071] col-span-2 sm:col-span-1">
                <div class="text-xs text-[#153d32] font-semibold">Sisa Bagasi</div>
                <strong id="k-match-bagasi" class="block mt-1 text-lg font-bold text-[#153d32]">24,0 L</strong>
                <span id="k-match-bagasi-sub" class="block text-[10px] text-[#5e7268]">120 − 96 = 24 L</span>
              </div>
            </div>

            <div class="formula-box mt-4 space-y-1.5 text-xs sm:text-sm">
              <div>
                <strong>Indeks Kemiripan:</strong>
                <span class="math-var">δ</span> = 1 − ½ × (Jarak Memutar ÷ Jarak via Hub) = <strong>0,82</strong>
              </div>
              <div>
                <strong>Sisa Kapasitas:</strong>
                <span class="math-var">V</span><sub>rem</sub> = <span class="math-var">V</span><sub>max</sub> − <span class="math-var">V</span><sub>isi</sub> = <span id="k-formula-vrem">30 − 24 = 6 paket</span>
                &nbsp;|&nbsp;
                <span class="math-var">V</span><sub>sisa_bagasi</sub> = <span id="k-formula-bagasi">120,0 − 96,0 = 24,0 L</span>
              </div>
            </div>

            <div class="mt-3 pt-3 border-t border-[#dbe4d5] flex flex-wrap items-center justify-between gap-3">
              <div>
                <span class="text-sm font-medium">Keputusan Rute: </span>
                <strong id="k-match-decision" class="text-sm sm:text-base font-bold text-[#287044]">Load-Sharing via Hub Merjosari</strong>
              </div>
              <span id="k-cmem-supply-tag" class="text-xs font-semibold text-[#5e7268]">Berat Muatan: 27,5 kg</span>
            </div>
          </div>
        </section>
