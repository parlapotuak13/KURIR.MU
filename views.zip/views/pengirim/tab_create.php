<section id="p-panel-create" class="p-panel">
          <div class="mb-4">
            <p class="eyebrow">PENGIRIM</p>
            <h2 class="brand text-2xl font-bold mt-0.5">Buat Pengiriman</h2>
          </div>

          <form id="p-form" class="space-y-4">
            <!-- Data Pengirim & Alamat -->
            <div class="surface-card p-5 space-y-4">
              <h3 class="font-bold text-base text-[#153d32]">Data Alamat</h3>
              <div class="grid sm:grid-cols-2 gap-3">
                <div>
                  <label for="p-sender" class="block text-xs font-bold mb-1 text-[#5e7268]">Nama Pengirim</label>
                  <input id="p-sender" class="field-input" required maxlength="80" value="UMKM Kopi Malang">
                </div>
                <div>
                  <label for="p-city" class="block text-xs font-bold mb-1 text-[#5e7268]">Kota</label>
                  <input id="p-city" class="field-input" value="Kota Malang" required maxlength="60">
                </div>
              </div>

              <div class="grid sm:grid-cols-2 gap-3">
                <div>
                  <label for="p-pd" class="block text-xs font-bold mb-1 text-[#5e7268]">Kecamatan Jemput</label>
                  <select id="p-pd" class="field-input">
                    <option value="Lowokwaru" selected>Lowokwaru</option>
                    <option value="Blimbing">Blimbing</option>
                    <option value="Klojen">Klojen</option>
                    <option value="Sukun">Sukun</option>
                    <option value="Kedungkandang">Kedungkandang</option>
                  </select>
                </div>
                <div>
                  <label for="p-dd" class="block text-xs font-bold mb-1 text-[#5e7268]">Kecamatan Tujuan</label>
                  <select id="p-dd" class="field-input">
                    <option value="Lowokwaru" selected>Lowokwaru</option>
                    <option value="Blimbing">Blimbing</option>
                    <option value="Klojen">Klojen</option>
                    <option value="Sukun">Sukun</option>
                    <option value="Kedungkandang">Kedungkandang</option>
                  </select>
                </div>
              </div>

              <div class="grid sm:grid-cols-2 gap-3">
                <div>
                  <label for="p-pa" class="block text-xs font-bold mb-1 text-[#5e7268]">Alamat Jemput</label>
                  <textarea id="p-pa" class="field-input" rows="2" required maxlength="200">Jl. MT Haryono No. 45, Dinoyo</textarea>
                </div>
                <div>
                  <label for="p-da" class="block text-xs font-bold mb-1 text-[#5e7268]">Alamat Tujuan</label>
                  <textarea id="p-da" class="field-input" rows="2" required maxlength="200">Jl. Gajayana No. 18, Ketawanggede</textarea>
                </div>
              </div>
            </div>

            <!-- Spesifikasi Fisik Paket: Berat (CMEM) & Dimensi P x L x T -->
            <div class="surface-card p-5 space-y-4">
              <h3 class="font-bold text-base text-[#153d32]">Berat &amp; Dimensi Paket (<span class="math-var">P</span> × <span class="math-var">L</span> × <span class="math-var">T</span>)</h3>

              <div class="grid sm:grid-cols-3 gap-3">
                <div>
                  <label for="p-pt" class="block text-xs font-bold mb-1 text-[#5e7268]">Jenis Paket</label>
                  <select id="p-pt" class="field-input">
                    <option>Paket kecil</option>
                    <option>Dokumen</option>
                    <option>Paket sedang</option>
                  </select>
                </div>
                <div>
                  <label for="p-qty" class="block text-xs font-bold mb-1 text-[#5e7268]">Jumlah Paket</label>
                  <input id="p-qty" type="number" min="1" max="18" value="2" required class="field-input font-bold">
                </div>
                <div>
                  <label for="p-weight" class="block text-xs font-bold mb-1 text-[#5e7268]">Berat Total Paket (kg)</label>
                  <input id="p-weight" type="number" min="0.1" max="60" step="0.1" value="3.5" required class="field-input font-bold">
                </div>
              </div>

              <div class="grid grid-cols-3 gap-3">
                <div>
                  <label for="p-dim-l" class="block text-xs font-bold mb-1 text-[#5e7268]">Panjang <span class="math-var">P</span> (cm)</label>
                  <input id="p-dim-l" type="number" min="1" max="150" step="1" value="30" required class="field-input font-bold">
                </div>
                <div>
                  <label for="p-dim-w" class="block text-xs font-bold mb-1 text-[#5e7268]">Lebar <span class="math-var">L</span> (cm)</label>
                  <input id="p-dim-w" type="number" min="1" max="150" step="1" value="20" required class="field-input font-bold">
                </div>
                <div>
                  <label for="p-dim-h" class="block text-xs font-bold mb-1 text-[#5e7268]">Tinggi <span class="math-var">T</span> (cm)</label>
                  <input id="p-dim-h" type="number" min="1" max="150" step="1" value="15" required class="field-input font-bold">
                </div>
              </div>

              <div>
                <label for="p-notes" class="block text-xs font-bold mb-1 text-[#5e7268]">Catatan</label>
                <input id="p-notes" class="field-input" maxlength="150" value="Kopi bubuk kemasan rapat">
              </div>

              <div class="formula-box space-y-2 text-xs sm:text-sm">
                <div class="grid sm:grid-cols-3 gap-2">
                  <div class="bg-white p-2.5 rounded-xl border border-[#dbe4d5]">
                    <span class="text-[11px] text-[#5e7268] block">Volume Total (<span class="math-var">P</span>×<span class="math-var">L</span>×<span class="math-var">T</span>×<span class="math-var">N</span>)</span>
                    <strong id="p-calc-vol" class="text-sm font-bold text-[#153d32]">18.000 cm³ (18,0 L)</strong>
                  </div>
                  <div class="bg-white p-2.5 rounded-xl border border-[#dbe4d5]">
                    <span class="text-[11px] text-[#5e7268] block">Berat Muatan (<span class="math-var">m</span><sub>load</sub>)</span>
                    <strong id="p-calc-weight" class="text-sm font-bold text-[#153d32]">3,5 kg (Total: 27,5 kg)</strong>
                  </div>
                  <div class="bg-white p-2.5 rounded-xl border border-[#dbe4d5]">
                    <span class="text-[11px] text-[#5e7268] block">Emisi CMEM (<span class="math-var">E</span><sub>CO₂</sub>)</span>
                    <strong id="p-calc-cmem" class="text-sm font-bold text-[#287044]">1,82 kg CO₂</strong>
                  </div>
                </div>
                <p class="text-[11px] text-[#5e7268] pt-1">Rumus CMEM: <span class="math-var">E</span><sub>CO₂</sub> = <span class="math-var">d</span> × (<span class="math-var">e</span><sub>dasar</sub> + <span class="math-var">γ</span> × <span class="math-var">m</span><sub>load</sub>)</p>
              </div>
            </div>

            <!-- Kalkulator Fungsi Objektif Green-Routing -->
            <div class="surface-card p-5 space-y-4">
              <div class="flex flex-wrap items-center justify-between gap-2">
                <h3 class="font-bold text-base text-[#153d32]">Kalkulator Fungsi Objektif</h3>
                <span class="formula-box py-1 px-3 text-xs font-bold">
                  <span class="math-var">Z</span> = <span class="math-var">α</span> × <span class="math-var">f</span><sub>fuel</sub> + <span class="math-var">β</span> × <span class="math-var">N</span><sub>stop</sub>
                </span>
              </div>

              <div class="grid sm:grid-cols-2 gap-5 pt-1">
                <div>
                  <div class="flex justify-between text-xs font-bold mb-1">
                    <label for="p-alpha">Bobot Bahan Bakar (<span class="math-var">α</span>)</label>
                    <output id="p-alpha-val" for="p-alpha" class="text-[#153d32]">0,70</output>
                  </div>
                  <input id="p-alpha" type="range" min="0" max="100" value="70">
                </div>
                <div>
                  <div class="flex justify-between text-xs font-bold mb-1">
                    <label for="p-beta">Bobot Pemberhentian (<span class="math-var">β</span>)</label>
                    <output id="p-beta-val" for="p-beta" class="text-[#153d32]">0,30</output>
                  </div>
                  <input id="p-beta" type="range" min="0" max="100" value="30">
                </div>
              </div>

              <div class="grid sm:grid-cols-2 gap-3">
                <div id="p-opt-direct" class="route-option border border-[#dbe4d5] rounded-xl p-4 transition">
                  <div class="flex justify-between items-center">
                    <strong class="text-sm">Rute Langsung</strong>
                    <span id="p-direct-params" class="text-xs text-[#5e7268]"><span class="math-var">f</span><sub>fuel</sub> = 8,0 · <span class="math-var">N</span><sub>stop</sub> = 3</span>
                  </div>
                  <div id="p-direct-score" class="brand text-xl font-bold mt-2 text-[#153d32]">Z = 6,50</div>
                </div>
                <div id="p-opt-hub" class="route-option winner border border-[#dbe4d5] rounded-xl p-4 transition">
                  <div class="flex justify-between items-center">
                    <strong class="text-sm">Rute via Hub</strong>
                    <span id="p-hub-params" class="text-xs text-[#5e7268]"><span class="math-var">f</span><sub>fuel</sub> = 5,0 · <span class="math-var">N</span><sub>stop</sub> = 5</span>
                  </div>
                  <div id="p-hub-score" class="brand text-xl font-bold mt-2 text-[#153d32]">Z = 5,00</div>
                </div>
              </div>
              <p id="p-best-route-text" class="text-xs sm:text-sm font-bold text-[#287044]"></p>
            </div>

            <!-- Pilihan Mode Pengiriman -->
            <fieldset class="surface-card p-5">
              <legend class="font-bold text-base text-[#153d32] mb-2 px-1">Pilih Mode Pengiriman</legend>
              <div class="grid sm:grid-cols-2 gap-3">
                <label class="border-2 border-[#2f7651] bg-[#e7f1d8]/50 rounded-xl p-3.5 cursor-pointer flex items-start gap-3">
                  <input type="radio" name="p-mode" value="hijau" checked class="mt-1 accent-[#153d32]">
                  <div>
                    <strong class="block text-sm">Pengiriman Hijau (Via Hub Merjosari)</strong>
                    <span class="text-xs text-[#5e7268] block mt-0.5">Penggabungan rute 2 vendor melalui micro-hub.</span>
                  </div>
                </label>
                <label class="border border-[#dbe4d5] bg-white rounded-xl p-3.5 cursor-pointer flex items-start gap-3">
                  <input type="radio" name="p-mode" value="langsung" class="mt-1 accent-[#153d32]">
                  <div>
                    <strong class="block text-sm">Rute Langsung</strong>
                    <span class="text-xs text-[#5e7268] block mt-0.5">Pengiriman langsung tanpa transit micro-hub.</span>
                  </div>
                </label>
              </div>
            </fieldset>

            <div id="p-form-err" class="bg-red-100 text-red-800 px-4 py-2.5 rounded-xl text-xs font-bold" hidden></div>

            <button id="p-submit" type="submit" class="btn-primary w-full py-3.5 text-base">Buat Pengiriman</button>
          </form>
        </section>
