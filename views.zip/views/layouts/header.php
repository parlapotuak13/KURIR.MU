<header class="bg-[#153d32] text-white sticky top-0 z-50 shadow-md">
      <div class="max-w-5xl mx-auto px-4 py-3">
        <div class="flex flex-wrap items-center justify-between gap-3">
          <div class="flex items-center gap-3">
            <div class="w-9 h-9 rounded-xl bg-[#b8e071] text-[#153d32] font-bold grid place-items-center text-lg shrink-0">🌿</div>
            <div>
              <div class="flex items-center gap-2">
                <h1 class="brand text-xl font-bold leading-none">Eco-LogiX</h1>
                <span id="header-role-pill" class="text-[11px] font-bold px-2.5 py-0.5 rounded-full bg-[#b8e071] text-[#153d32]">Pengirim</span>
              </div>
            </div>
          </div>

          <div class="flex flex-wrap items-center gap-2">
            <div class="flex items-center gap-2 bg-[#0f2e25] px-3 py-1.5 rounded-full border border-white/15 text-xs">
              <span id="active-user-label" class="font-bold text-white">Pengguna</span>
            </div>
            <button type="button" id="btn-global-reset" class="px-3 py-1.5 rounded-full bg-white/10 hover:bg-white/20 text-white text-xs font-semibold transition cursor-pointer">Reset</button>
            <button type="button" id="btn-logout" class="px-3 py-1.5 rounded-full bg-[#b8e071] text-[#153d32] hover:bg-[#c9ec85] text-xs font-bold transition cursor-pointer">Keluar</button>
          </div>
        </div>
      </div>
    </header>
