<nav class="bottom-nav" aria-label="Navigasi utama">
      <div id="nav-pengirim" class="max-w-xl mx-auto grid grid-cols-4 gap-1" hidden>
        <button type="button" class="sub-tab-btn active" data-p-tab="create"><span class="block text-base">➕</span>Buat</button>
        <button type="button" class="sub-tab-btn" data-p-tab="track"><span class="block text-base">📍</span>Lacak</button>
        <button type="button" class="sub-tab-btn" data-p-tab="history"><span class="block text-base">📋</span>Riwayat</button>
        <button type="button" class="sub-tab-btn" data-p-tab="impact"><span class="block text-base">🌱</span>Dampak</button>
      </div>
      <div id="nav-kurir" class="max-w-xl mx-auto grid grid-cols-5 gap-1" hidden>
        <button type="button" class="sub-tab-btn active" data-k-tab="dashboard"><span class="block text-base">🗺️</span>Dasbor</button>
        <button type="button" class="sub-tab-btn" data-k-tab="tasks"><span class="block text-base">🤝</span>Pencocokan</button>
        <button type="button" class="sub-tab-btn" data-k-tab="route"><span class="block text-base">🧭</span>Rute</button>
        <button type="button" class="sub-tab-btn" data-k-tab="hub"><span class="block text-base">🏢</span>Hub</button>
        <button type="button" class="sub-tab-btn" data-k-tab="verify"><span class="block text-base">🔐</span>Verifikasi</button>
      </div>
      <div id="nav-vendor" class="max-w-xl mx-auto grid grid-cols-4 gap-1" hidden>
        <button type="button" class="sub-tab-btn active" data-v-tab="dashboard"><span class="block text-base">📊</span>Dasbor</button>
        <button type="button" class="sub-tab-btn" data-v-tab="fleet"><span class="block text-base">🚚</span>Armada</button>
        <button type="button" class="sub-tab-btn" data-v-tab="collab"><span class="block text-base">⇄</span>Kolaborasi</button>
        <button type="button" class="sub-tab-btn" data-v-tab="report"><span class="block text-base">📑</span>Laporan</button>
      </div>
    </nav>
