-- ============================================================================
-- ECO-LOGIX · FILE IMPORT LENGKAP (DATABASE + TABEL + DATA AWAL)
-- ============================================================================

CREATE DATABASE IF NOT EXISTS `ecologix_db` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `ecologix_db`;

-- ============================================================================
-- ECO-LOGIX · STRUKTUR TABEL MYSQL (DDL)
-- ============================================================================

CREATE TABLE IF NOT EXISTS `users` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(100) NOT NULL,
  `email` VARCHAR(120) NOT NULL,
  `password_hash` VARCHAR(255) NOT NULL,
  `role` ENUM('pengirim', 'kurir', 'vendor') NOT NULL DEFAULT 'pengirim',
  `courier_code` ENUM('a', 'b') DEFAULT NULL,
  `badge` VARCHAR(60) NOT NULL DEFAULT 'Pengirim',
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_users_email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `shipments` (
  `id` VARCHAR(24) NOT NULL,
  `user_id` INT UNSIGNED DEFAULT NULL,
  `sender` VARCHAR(80) NOT NULL,
  `city` VARCHAR(60) NOT NULL DEFAULT 'Kota Malang',
  `pickup_district` VARCHAR(60) NOT NULL,
  `pickup_address` VARCHAR(200) NOT NULL,
  `destination_district` VARCHAR(60) NOT NULL,
  `destination_address` VARCHAR(200) NOT NULL,
  `package_type` ENUM('Dokumen', 'Paket kecil', 'Paket sedang') NOT NULL DEFAULT 'Paket kecil',
  `quantity` INT UNSIGNED NOT NULL DEFAULT 1,
  `weight_kg` DECIMAL(8,2) NOT NULL DEFAULT 3.50,
  `dim_l` DECIMAL(8,2) NOT NULL DEFAULT 30.00,
  `dim_w` DECIMAL(8,2) NOT NULL DEFAULT 20.00,
  `dim_h` DECIMAL(8,2) NOT NULL DEFAULT 15.00,
  `volume_cm3` DECIMAL(12,2) NOT NULL DEFAULT 18000.00,
  `volume_liters` DECIMAL(8,2) NOT NULL DEFAULT 18.00,
  `notes` VARCHAR(255) NOT NULL DEFAULT '',
  `mode` ENUM('hijau', 'langsung') NOT NULL DEFAULT 'hijau',
  `stage` TINYINT UNSIGNED NOT NULL DEFAULT 0,
  `otp` CHAR(4) NOT NULL,
  `created_at` BIGINT UNSIGNED NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_shipments_created` (`created_at`),
  CONSTRAINT `fk_shipments_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `system_state` (
  `id` TINYINT UNSIGNED NOT NULL DEFAULT 1,
  `courier` CHAR(1) NOT NULL DEFAULT 'a',
  `progress` INT UNSIGNED NOT NULL DEFAULT 0,
  `verified` TINYINT(1) NOT NULL DEFAULT 0,
  `otp` CHAR(4) NOT NULL DEFAULT '4829',
  `alpha` INT UNSIGNED NOT NULL DEFAULT 70,
  `beta` INT UNSIGNED NOT NULL DEFAULT 30,
  `selected_shipment_id` VARCHAR(24) NOT NULL DEFAULT 'ELX-MLG01',
  `vendor_sharing` TINYINT(1) NOT NULL DEFAULT 1,
  `vendor_threshold` DECIMAL(4,2) NOT NULL DEFAULT 0.75,
  `vendor_detour` DECIMAL(5,2) NOT NULL DEFAULT 2.00,
  `vendor_area` TINYINT(1) NOT NULL DEFAULT 1,
  `vendor_volume` TINYINT(1) NOT NULL DEFAULT 1,
  `vendor_weight` TINYINT(1) NOT NULL DEFAULT 1,
  `vendor_decision` ENUM('approved', 'rejected', 'pending') NOT NULL DEFAULT 'approved',
  `vendor_decided_at` BIGINT UNSIGNED DEFAULT 1731200000000,
  `vendor_sync_at` BIGINT UNSIGNED NOT NULL DEFAULT 1731200000000,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `vendor_history` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `decision` ENUM('approved', 'rejected') NOT NULL,
  `decided_at` BIGINT UNSIGNED NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_vendor_history_at` (`decided_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `handover_logs` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `shipment_id` VARCHAR(24) DEFAULT NULL,
  `otp` CHAR(4) NOT NULL,
  `log_text` VARCHAR(255) NOT NULL,
  `created_at` BIGINT UNSIGNED NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_handover_logs_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- ECO-LOGIX · DATA AWAL (SEEDER)
-- ============================================================================

INSERT IGNORE INTO `users` (`id`, `name`, `email`, `password_hash`, `role`, `courier_code`, `badge`) VALUES
(1, 'UMKM Kopi Malang', 'pengirim@umkm-malang.id', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'pengirim', NULL, 'Pengirim'),
(2, 'Budi Santoso', 'kurir.a@ecohemat.id', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'kurir', 'a', 'Kurir · Eco Hemat'),
(3, 'Andi Pratama', 'kurir.b@kilatraya.id', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'kurir', 'b', 'Kurir · Kilat Raya'),
(4, 'Rina Wijaya', 'admin@ecohemat-3pl.id', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'vendor', NULL, 'Vendor 3PL');

INSERT IGNORE INTO `shipments` (
  `id`, `user_id`, `sender`, `city`, `pickup_district`, `pickup_address`,
  `destination_district`, `destination_address`, `package_type`, `quantity`,
  `weight_kg`, `dim_l`, `dim_w`, `dim_h`, `volume_cm3`, `volume_liters`,
  `notes`, `mode`, `stage`, `otp`, `created_at`
) VALUES (
  'ELX-MLG01', 1, 'UMKM Kopi Malang', 'Kota Malang',
  'Lowokwaru', 'Jl. MT Haryono No. 45, Dinoyo',
  'Lowokwaru', 'Jl. Gajayana No. 18, Ketawanggede',
  'Paket kecil', 2, 3.50, 30.00, 20.00, 15.00, 18000.00, 18.00,
  'Kopi bubuk kemasan rapat', 'hijau', 0, '4829', 1731200000000
);

INSERT IGNORE INTO `system_state` (
  `id`, `courier`, `progress`, `verified`, `otp`, `alpha`, `beta`,
  `selected_shipment_id`, `vendor_sharing`, `vendor_threshold`, `vendor_detour`,
  `vendor_area`, `vendor_volume`, `vendor_weight`, `vendor_decision`,
  `vendor_decided_at`, `vendor_sync_at`
) VALUES (
  1, 'a', 0, 0, '4829', 70, 30, 'ELX-MLG01', 1, 0.75, 2.00, 1, 1, 1, 'approved', 1731200000000, 1731200000000
);

INSERT IGNORE INTO `vendor_history` (`id`, `decision`, `decided_at`) VALUES
(1, 'approved', 1731200000000);
