-- ============================================================================
-- ECO-LOGIX · DATA AWAL (SEEDER)
-- ============================================================================

INSERT IGNORE INTO `users` (`id`, `name`, `email`, `password_hash`, `role`, `courier_code`, `badge`) VALUES
(1, 'UMKM Kopi Malang', 'pengirim@umkm-malang.id', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'pengirim', NULL, 'Pengirim'),
(2, 'Budi Santoso', 'kurir.a@ecohemat.id', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'kurir', 'a', 'Kurir · Eco Hemat'),
(3, 'Andi Pratama', 'kurir.b@kilatraya.id', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'kurir', 'b', 'Kurir · Kilat Raya'),
(4, 'Rina Wijaya', 'admin@ecohemat-3pl.id', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'vendor', NULL, 'Vendor 3PL');

INSERT IGNORE INTO `shipments` (
  `id`, `user_id`, `sender`, `city`, `pickup_district`, `pickup_address`,
  `destination_district`, `destination_address`, `package_type`, `quantity`,
  `weight_kg`, `dim_l`, `dim_w`, `dim_h`, `volume_cm3`, `volume_liters`,
  `notes`, `mode`, `stage`, `otp`, `created_at`
) VALUES (
  'ELX-MLG01', 1, 'UMKM Kopi Malang', 'Kota Malang',
  'Lowokwaru', 'Jl. MT Haryono No. 45, Dinoyo',
  'Lowokwaru', 'Jl. Gajayana No. 18, Ketawanggede',
  'Paket kecil', 2, 3.50, 30.00, 20.00, 15.00, 18000.00, 18.00,
  'Kopi bubuk kemasan rapat', 'hijau', 0, '4829', 1731200000000
);

INSERT IGNORE INTO `system_state` (
  `id`, `courier`, `progress`, `verified`, `otp`, `alpha`, `beta`,
  `selected_shipment_id`, `vendor_sharing`, `vendor_threshold`, `vendor_detour`,
  `vendor_area`, `vendor_volume`, `vendor_weight`, `vendor_decision`,
  `vendor_decided_at`, `vendor_sync_at`
) VALUES (
  1, 'a', 0, 0, '4829', 70, 30, 'ELX-MLG01', 1, 0.75, 2.00, 1, 1, 1, 'approved', 1731200000000, 1731200000000
);

INSERT IGNORE INTO `vendor_history` (`id`, `decision`, `decided_at`) VALUES
(1, 'approved', 1731200000000);
