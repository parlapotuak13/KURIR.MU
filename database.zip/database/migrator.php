<?php
declare(strict_types=1);

/**
 * Menjalankan inisialisasi skema tabel & data awal secara otomatis
 * apabila tabel belum ada di dalam database MySQL.
 */
function runDatabaseMigrator(PDO $pdo): void
{
    $schemaFile = __DIR__ . '/schema.sql';
    if (is_file($schemaFile)) {
        $sql = (string) file_get_contents($schemaFile);
        foreach (array_filter(array_map('trim', explode(';', $sql))) as $stmt) {
            if ($stmt !== '') {
                $pdo->exec($stmt);
            }
        }
    }

    $stateCount = (int) $pdo->query("SELECT COUNT(*) FROM `system_state` WHERE `id` = 1")->fetchColumn();
    if ($stateCount === 0) {
        $seedFile = __DIR__ . '/seed.sql';
        if (is_file($seedFile)) {
            $seedSql = (string) file_get_contents($seedFile);
            foreach (array_filter(array_map('trim', explode(';', $seedSql))) as $stmt) {
                if ($stmt !== '') {
                    $pdo->exec($stmt);
                }
            }
        }
    }
}
